import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""

// Log Supabase configuration status (without revealing actual values)
console.log("Supabase Configuration Status:")
console.log(`- URL: ${supabaseUrl ? "Set" : "Not set"}`)
console.log(`- Service Role Key: ${supabaseKey ? "Set" : "Not set"}`)

if (!supabaseUrl || !supabaseKey) {
  console.error("WARNING: Supabase URL or Service Role Key is missing. Database operations will fail.")
}

// Create a single instance of the Supabase client to reuse
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false,
  },
  global: {
    headers: {
      "x-application-name": "edition-numbering-system",
    },
  },
})

// Helper function to check if Supabase is configured
export function isSupabaseConfigured(): boolean {
  return Boolean(supabaseUrl && supabaseKey)
}

// Helper function to test the Supabase connection
export async function testSupabaseConnection() {
  try {
    const { data, error } = await supabase.from("order_line_items").select("count", { count: "exact", head: true })

    if (error) {
      console.error("Supabase connection test failed:", error)
      return {
        success: false,
        message: "Failed to connect to Supabase",
        error: error.message,
      }
    }

    return {
      success: true,
      message: "Successfully connected to Supabase",
      data,
    }
  } catch (error: any) {
    console.error("Error testing Supabase connection:", error)
    return {
      success: false,
      message: "Error testing Supabase connection",
      error: error.message,
    }
  }
}

