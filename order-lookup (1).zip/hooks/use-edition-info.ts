"use client"

import { useState, useEffect } from "react"
import { getEditionFromSupabase, getSequentialNumber, getEditionNumber } from "@/lib/api"

export interface EditionInfo {
  number: string
  source: string
  total?: string
  note?: string
  updated_at?: string
  uuid?: string
  status?: "active" | "removed"
  removed_reason?: string
}

export function useEditionInfo(item: any): {
  editionInfo: EditionInfo | null
  isLoading: boolean
  error: string | null
  refreshEditionInfo: () => Promise<void>
} {
  const [editionInfo, setEditionInfo] = useState<EditionInfo | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  const determineEditionNumber = async () => {
    if (!item || !item.order_info) {
      setIsLoading(false)
      return
    }

    try {
      setIsLoading(true)
      setError(null)

      // First try to get edition from Supabase (our source of truth)
      if (item.order_info && item.order_info.order_id && item.line_item_id) {
        try {
          const supabaseData = await getEditionFromSupabase(item.order_info.order_id, item.line_item_id)

          if (supabaseData && (supabaseData.editionNumber || supabaseData.edition_number)) {
            // Check if the item is marked as removed
            const isRemoved = supabaseData.status === "removed" || supabaseData.removed_reason

            setEditionInfo({
              number: (supabaseData.editionNumber || supabaseData.edition_number).toString(),
              source: "supabase",
              total: supabaseData.editionTotal || supabaseData.edition_total || item.total_inventory,
              note:
                supabaseData.note || (isRemoved ? "This item has been marked as removed" : "Verified edition number"),
              updated_at: supabaseData.updatedAt || supabaseData.updated_at,
              status: supabaseData.status || "active",
              removed_reason: supabaseData.removedReason || supabaseData.removed_reason,
            })
            setIsLoading(false)
            return
          }
        } catch (error) {
          console.error("Error fetching from Supabase, trying next method:", error)
          // Continue to next method
        }
      }

      // If Supabase doesn't have the data, fall back to sequential number API
      if (item.order_info && item.order_info.order_id && item.line_item_id) {
        try {
          const sequentialData = await getSequentialNumber(item.order_info.order_id, item.line_item_id)

          if (sequentialData && (sequentialData.sequentialNumber || sequentialData.sequential_number)) {
            setEditionInfo({
              number: (sequentialData.sequentialNumber || sequentialData.sequential_number).toString(),
              source: "sequential_uuid",
              total: sequentialData.editionTotal || sequentialData.edition_total || item.total_inventory,
              note: "Guaranteed sequential number",
              uuid: sequentialData.sequentialUuid || sequentialData.sequential_uuid,
            })
            setIsLoading(false)
            return
          }
        } catch (error) {
          console.error("Error fetching sequential number, trying next method:", error)
          // Continue to next method
        }
      }

      // Fall back to the existing logic if API calls fail or no sequential number exists
      if (item.order_info && item.order_info.order_id && item.line_item_id && item.product_id) {
        try {
          const editionData = await getEditionNumber(item.order_info.order_id, item.line_item_id, item.product_id)

          if (editionData && (editionData.editionNumber || editionData.edition_number)) {
            setEditionInfo({
              number: (editionData.editionNumber || editionData.edition_number).toString(),
              source: "sequential_order",
              total: editionData.editionTotal || editionData.edition_total || item.total_inventory,
              note: editionData.note || "Based on order sequence",
            })
            setIsLoading(false)
            return
          }
        } catch (error) {
          console.error("Error fetching edition number, trying fallback methods:", error)
          // Continue to fallback methods
        }
      }

      // Check if we have a valid commitment number from custom attributes or metafields
      if (item.commitment_number && /^\d+$/.test(item.commitment_number)) {
        setEditionInfo({
          number: item.commitment_number,
          source: "commitment",
          total: item.total_inventory,
        })
        setIsLoading(false)
        return
      }

      // Check for edition number in properties
      if (item.properties && Array.isArray(item.properties)) {
        const editionNumberProp = item.properties.find(
          (prop: any) => prop.name === "_edition_number" || prop.name === "edition_number",
        )
        const editionTotalProp = item.properties.find(
          (prop: any) => prop.name === "_edition_total" || prop.name === "edition_total",
        )

        if (editionNumberProp) {
          setEditionInfo({
            number: editionNumberProp.value.toString(),
            source: "properties",
            total: editionTotalProp ? editionTotalProp.value : item.total_inventory,
            note: "From order properties",
          })
          setIsLoading(false)
          return
        }
      }

      // If we have a variant position, use that
      if (item.variant && item.variant.position && item.variant.position > 0) {
        setEditionInfo({
          number: item.variant.position.toString(),
          source: "variant_position",
          total: item.total_inventory,
        })
        setIsLoading(false)
        return
      }

      // If we have order info, use the order number as a proxy for sequence
      if (item.order_info && item.order_info.order_number) {
        // Use a different approach - use the last digits of the order number
        // This ensures different orders get different numbers
        const orderNum = item.order_info.order_number.toString()
        const lastDigits = orderNum.slice(-2) // Get last 2 digits
        const editionNum = Number.parseInt(lastDigits, 10) || 1

        setEditionInfo({
          number: editionNum.toString(),
          source: "order_sequence",
          note: "Based on order number",
          total: item.total_inventory,
        })
        setIsLoading(false)
        return
      }

      // Default fallback - use a random number between 1 and total_inventory
      const total = item.total_inventory ? Number.parseInt(item.total_inventory, 10) : 100
      const randomNum = Math.floor(Math.random() * total) + 1

      setEditionInfo({
        number: randomNum.toString(),
        source: "random",
        note: "Estimated position",
        total: item.total_inventory,
      })
    } catch (err) {
      console.error("Error determining edition number:", err)
      setError("Failed to retrieve edition information")

      // Fallback to a random edition number
      const total = item.total_inventory ? Number.parseInt(item.total_inventory, 10) : 100
      const randomNum = Math.floor(Math.random() * total) + 1

      setEditionInfo({
        number: randomNum.toString(),
        source: "random",
        note: "Estimated position (fallback)",
        total: item.total_inventory,
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    determineEditionNumber()
  }, [item])

  const refreshEditionInfo = async () => {
    await determineEditionNumber()
  }

  return { editionInfo, isLoading, error, refreshEditionInfo }
}

